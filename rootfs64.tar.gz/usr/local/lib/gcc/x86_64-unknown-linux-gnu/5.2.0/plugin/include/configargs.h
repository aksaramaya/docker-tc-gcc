/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-5.2.0/configure --prefix=/usr/local --enable-languages=c,c++ --disable-multilib --disable-bootstrap --with-system-zlib --libexecdir=/usr/local/lib --enable-frame-pointer --enable-gold";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
